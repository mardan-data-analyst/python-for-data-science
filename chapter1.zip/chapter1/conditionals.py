### Grant access if user  password is correct
##
##password_pool = ('Smith_crete', 'Alex@56', 'CEO4life')
##
##user_password = input('Please, enter your password: \t')
##
### Now the IF condition
##if user_password in password_pool:
##    print('\n Access granted!')


### Grant access if user  password is correct 
### Otherwise, raise  and alarm.
##
##password_pool = ('Smith_crete', 'Alex@456', 'CEO4life')
##
##user_password = input('Please, enter your password: \t')
##
### Now the IF-ELIF-ELSE conditions.
##
##if user_password in password_pool and user_password == 'Smith_crete':
##    print('\nAccess granted! Welcome Dr. Smith!')
##elif user_password in password_pool and user_password == 'Alex@456':
##    print('\nAccess granted! Welcome, Mr.Alexander!')
##elif user_password in password_pool and user_password == 'CEO4life':
##    print('\nAccess granted! Welcome, Mr.CEO!')
##else:
##    print('\nAccess Denied! Calling Security ...')




